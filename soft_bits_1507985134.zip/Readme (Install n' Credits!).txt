Thanks for downloading the PlasticCraft Resource pack!
Soft Nits By WolfieTundra@Planetminecraft.com
-----------
How to install:
1.Download the Soft Bits resource pack
2.Run Minecraft
3.Click "Resource Packs"
4.Click "Open Res.Pack folder"
5.Put the Soft Bits.zip file in there
6.Select it,and play!
-----------
You're Allowed To:
- Use The Texture Pack (Duh :D).
- Edit it ONLY for personal use.
- Showcase it on YouTube. (I'll be glad if you Notify me :V)

You aren't Allowed to:
- Claim it as Yours.
- Upload an edited version.
- Use another download link other than the PMC one in YouTube Showcases,etc.
-----------
Follow the newest versions of the PlasticCraft Pack at PlanetMinecraft.com!
If you like the pack, please support me by giving the pack a diamond at Planet Minecraft!
Subscribe on PMC to be notified with updated an special ONLY SUBSCRIBERS messages!
-----------
Texture Contribution:
- Hunger Bar and XP (and color) bars By VeryMadCrafter
===========

ORIGINAL LINK: https://www.planetminecraft.com/texture_pack/soft-bits-simple-and-soft/

